import React, { Component } from 'react';

class Profile extends Component {
    render() {
        return (
            <div>
               <h1>Hello My Name is John!</h1> 
               <img src="http://www.placecage.com/200/300" />
                <h1>Nic Cage</h1>
                <h3>Full Stack Developer</h3>
            </div>
        );
    }
}

export default Profile;
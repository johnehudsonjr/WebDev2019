import React, { Component } from 'react';

class Specialties extends Component {
    render() {
        return (
            <div>
                <h2> I speacialize in JavaScript</h2>
            </div>
        );
    }
}

export default Specialties;